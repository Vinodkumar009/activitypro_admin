import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddingtornamentmemberPage } from './addingtornamentmember';

@NgModule({
  declarations: [
    AddingtornamentmemberPage,
  ],
  imports: [
    IonicPageModule.forChild(AddingtornamentmemberPage),
  ],
})
export class AddingtornamentmemberPageModule {}
