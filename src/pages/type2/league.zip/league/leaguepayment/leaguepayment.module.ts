import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LeaguepaymentPage } from './leaguepayment';

@NgModule({
  declarations: [
    LeaguepaymentPage,
  ],
  imports: [
    IonicPageModule.forChild(LeaguepaymentPage),
  ],
})
export class LeaguepaymentPageModule {}
