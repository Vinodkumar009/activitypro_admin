import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TeaminvitePage } from './teaminvite';

@NgModule({
  declarations: [
    TeaminvitePage,
  ],
  imports: [
    IonicPageModule.forChild(TeaminvitePage),
  ],
})
export class TeaminvitePageModule {}
