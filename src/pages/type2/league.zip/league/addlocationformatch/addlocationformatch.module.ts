import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddlocationformatchPage } from './addlocationformatch';

@NgModule({
  declarations: [
    AddlocationformatchPage,
  ],
  imports: [
    IonicPageModule.forChild(AddlocationformatchPage),
  ],
})
export class AddlocationformatchPageModule {}
