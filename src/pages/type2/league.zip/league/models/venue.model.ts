export class ClubVenue {
     Id: String;
    // Message: String;
    // CreatedAt: String;
    // UpdatedAt: String;
    ClubName: string;
    ClubKey: string;
    LocationType: number;
  }