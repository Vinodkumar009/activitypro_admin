

export class Activity{
    ActivityCode:number;
    ActivityName:string;
    ActivityKey:string
}