import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AutocreatematchPage } from './autocreatematch';

@NgModule({
  declarations: [
    AutocreatematchPage,
  ],
  imports: [
    IonicPageModule.forChild(AutocreatematchPage),
  ],
})
export class AutocreatematchPageModule {}
