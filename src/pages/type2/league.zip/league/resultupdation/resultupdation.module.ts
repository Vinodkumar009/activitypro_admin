import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ResultupdationPage } from './resultupdation';

@NgModule({
  declarations: [
    ResultupdationPage,
  ],
  imports: [
    IonicPageModule.forChild(ResultupdationPage),
  ],
})
export class ResultupdationPageModule {}
