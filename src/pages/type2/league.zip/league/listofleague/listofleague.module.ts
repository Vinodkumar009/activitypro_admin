import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ListofleaguePage } from './listofleague';

@NgModule({
  declarations: [
    ListofleaguePage,
  ],
  imports: [
    IonicPageModule.forChild(ListofleaguePage),
  ],
})
export class ListofleaguePageModule {}
