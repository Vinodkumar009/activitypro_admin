import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditmatchPage } from './editmatch';

@NgModule({
  declarations: [
    EditmatchPage,
  ],
  imports: [
    IonicPageModule.forChild(EditmatchPage),
  ],
})
export class EditmatchPageModule {}
