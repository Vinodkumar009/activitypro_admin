import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { UpcomingmatchPage } from './upcomingmatch';

@NgModule({
  declarations: [
    UpcomingmatchPage,
  ],
  imports: [
    IonicPageModule.forChild(UpcomingmatchPage),
  ],
})
export class UpcomingmatchPageModule {}
