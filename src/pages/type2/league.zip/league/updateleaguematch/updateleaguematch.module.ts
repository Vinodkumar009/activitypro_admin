import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { UpdateleaguematchPage } from './updateleaguematch';

@NgModule({
  declarations: [
    UpdateleaguematchPage,
  ],
  imports: [
    IonicPageModule.forChild(UpdateleaguematchPage),
  ],
})
export class UpdateleaguematchPageModule {}
