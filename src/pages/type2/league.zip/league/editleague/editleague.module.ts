import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditleaguePage } from './editleague';

@NgModule({
  declarations: [
    EditleaguePage,
  ],
  imports: [
    IonicPageModule.forChild(EditleaguePage),
  ],
})
export class EditleaguePageModule {}
