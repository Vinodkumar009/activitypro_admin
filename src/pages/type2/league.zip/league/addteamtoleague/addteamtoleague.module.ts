import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddteamtoleaguePage } from './addteamtoleague';

@NgModule({
  declarations: [
    AddteamtoleaguePage,
  ],
  imports: [
    IonicPageModule.forChild(AddteamtoleaguePage),
  ],
})
export class AddteamtoleaguePageModule {}
