import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CreatematchleaguePage } from './creatematchleague';

@NgModule({
  declarations: [
    CreatematchleaguePage,
  ],
  imports: [
    IonicPageModule.forChild(CreatematchleaguePage),
  ],
})
export class CreatematchleaguePageModule {}
