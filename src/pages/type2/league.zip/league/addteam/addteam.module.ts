import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddteamPage } from './addteam';

@NgModule({
  declarations: [
    AddteamPage,
  ],
  imports: [
    IonicPageModule.forChild(AddteamPage),
  ],
})
export class AddteamPageModule {}
